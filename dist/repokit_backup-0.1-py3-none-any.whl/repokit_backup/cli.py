"""
CLI interface - Argument parsing and command dispatch.
"""

import argparse
import json
import pathlib
import sys

import repokit_common

# from ..common import ensure_correct_kernel
from .rclone import (
    generate_diff_report,
    install_rclone,
    pull_rclone,
    push_rclone,
    transfer_between_remotes,
)
from .remotes import (
    _detect_remote_type,
    check_lumi_o_credentials,
    delete_remote,
    list_remotes,
    list_supported_remote_types,
    set_host_port,
    setup_rclone,
)

SUPPORTED_REMOTE_PREFIXES = (
    "dropbox",
    "onedrive",
    "googledrive",
    "gdrive",
    "erda",
    "ucloud",
    "lumi",
    "local",
    "s3",
    "sftp",
)


def _has_valid_remote_prefix(remote_name: str) -> bool:
    """
    Enforce explicit backend prefix in remote aliases to avoid wrong type inference.
    Valid examples: dropbox-teamdata, onedrive_proj, sftp-myhost.
    """
    name = (remote_name or "").strip().lower()
    for prefix in SUPPORTED_REMOTE_PREFIXES:
        if name == prefix:
            return True
        if name.startswith(prefix):
            next_char = name[len(prefix) : len(prefix) + 1]
            if next_char in {"-", "_", ":"}:
                return True
    return False


def _ensure_rcloneignore_pyproject_config() -> None:
    """
    Ensure pyproject.toml exists and has [tool.rcloneignore] defaults.
    """
    defaults = {
        "tool-description": "Ignore patterns for backup and remote synchronization.",
        "tool-replaces": ".rcloneignore",
        "patterns": ["bin/", ".venv/", ".conda/"],
    }

    current = repokit_common.read_toml(
        folder=str(repokit_common.PROJECT_ROOT),
        json_filename=repokit_common.JSON_FILENAME,
        tool_name="rcloneignore",
        toml_path=repokit_common.TOML_PATH,
    ) or {}

    patterns = current.get("patterns", [])
    if isinstance(patterns, str):
        pattern_list = [patterns]
    elif isinstance(patterns, list):
        pattern_list = [p for p in patterns if isinstance(p, str) and p.strip()]
    else:
        pattern_list = []

    merged_patterns = list(pattern_list)
    seen = {p.strip() for p in pattern_list}
    for p in defaults["patterns"]:
        if p not in seen:
            merged_patterns.append(p)
            seen.add(p)

    payload = {
        "tool-description": current.get("tool-description") or defaults["tool-description"],
        "tool-replaces": current.get("tool-replaces") or defaults["tool-replaces"],
        "patterns": merged_patterns,
    }

    repokit_common.write_toml(
        data=payload,
        folder=str(repokit_common.PROJECT_ROOT),
        json_filename=repokit_common.JSON_FILENAME,
        tool_name="rcloneignore",
        toml_path=repokit_common.TOML_PATH,
    )


# @ensure_correct_kernel
def main():
    """Main CLI entry point."""
    # When running standalone, treat the current working directory as the project root.
    repokit_common.PROJECT_ROOT = pathlib.Path.cwd().resolve()
    _ensure_rcloneignore_pyproject_config()

    if not install_rclone("./bin"):
        print("Error: rclone installation/verification failed.")
        sys.exit(1)

    parser = argparse.ArgumentParser(description="Backup manager CLI using rclone")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Global arguments
    parser.add_argument(
        "--dry-run", action="store_true", help="Do not modify remote; show actions."
    )
    parser.add_argument(
        "-v", "--verbose", action="count", default=1, help="Increase verbosity (-v, -vv, -vvv)."
    )

    # List command
    subparsers.add_parser("list", help="List rclone remotes and mapped folders")

    # Types command
    subparsers.add_parser("types", help="List supported remote types")

    # Add command
    add = subparsers.add_parser("add", help="Add a remote and folder mapping")
    add.add_argument("--remote", required=True, help="Remote name")
    add.add_argument(
        "--local-path",
        "--local_path",
        dest="local_path",
        help="Specific local path to backup",
    )
    add.add_argument(
        "--token",
        dest="oauth_token",
        help="OAuth token JSON output from `rclone authorize` (dropbox/onedrive/drive)",
    )
    add.add_argument(
        "--token-file",
        dest="oauth_token_file",
        help="Path to file containing OAuth token JSON output from `rclone authorize`",
    )
    add.add_argument(
        "--ssh",
        "--ssh-mode",
        "--shh-mode",
        dest="ssh_mode",
        action="store_true",
        help="Enable SSH tunnel instructions for OAuth remotes (headless setup).",
    )

    # Push command
    push = subparsers.add_parser("push", help="Push/backup to remote")
    push.add_argument("--remote", required=True, help="Remote name")
    push.add_argument(
        "--mode",
        choices=["sync", "copy", "move"],
        default="sync",
        help="sync: mirror (default), copy: no deletes, move: delete source after",
    )
    push.add_argument("--remote-path", help="remote path to backup")
    push.add_argument(
        "--select",
        action="store_true",
        help="Interactively select top-level files/folders to transfer.",
    )

    # Pull command
    pull = subparsers.add_parser("pull", help="Pull/restore from remote")
    pull.add_argument("--remote", required=True, help="Remote name")
    pull.add_argument(
        "--mode",
        choices=["sync", "copy", "move"],
        default="sync",
        help="sync: mirror (default), copy: no deletes, move: delete source after",
    )
    pull.add_argument(
        "--local-path",
        "--local_path",
        dest="local_path",
        help="Override destination path",
    )
    pull.add_argument(
        "--select",
        action="store_true",
        help="Interactively select top-level files/folders to transfer.",
    )

    # Delete command
    delete = subparsers.add_parser("delete", help="Delete a remote and its mapping")
    delete.add_argument("--remote", required=True, help="Remote name or 'all'")

    # Diff command
    diff = subparsers.add_parser("diff", help="Generate a diff report for a remote")
    diff.add_argument("--remote", required=True, help="Remote name")

    # Transfer command (remote-to-remote)
    transfer = subparsers.add_parser("transfer", help="Transfer data between two remotes")
    transfer.add_argument("--source", required=True, help="Source remote name")
    transfer.add_argument("--destination", required=True, help="Destination remote name")
    transfer.add_argument(
        "--mode", choices=["copy", "sync"], default="copy", help="Operation: copy or sync"
    )
    transfer.add_argument(
        "--confirm", action="store_true", help="Confirm execution (otherwise dry-run)"
    )

    args = parser.parse_args()

    # Normalize shorthand local path to the absolute current working directory.
    if hasattr(args, "local_path") and args.local_path == ".":
        args.local_path = str(pathlib.Path.cwd().resolve())

    # Handle commands
    if hasattr(args, "remote") and args.remote:
        remote = args.remote.strip().lower()

        if args.command in {"add", "push", "pull", "delete", "diff"}:
            if remote != "all" and not _has_valid_remote_prefix(remote):
                allowed = ", ".join(SUPPORTED_REMOTE_PREFIXES)
                print(
                    "Error: --remote must start with a supported backend prefix "
                    f"({allowed}) and should use a separator like '-' or '_'."
                )
                print("Example: --remote dropbox-teamdata")
                sys.exit(2)

        # Handle LUMI credentials
        if "lumi" in remote:
            remote = check_lumi_o_credentials(remote_name=remote, command=args.command)
            if remote is None:
                return

        # Set host/port for SFTP remotes
        if args.command in {"add", "push", "pull"}:
            remote_type = _detect_remote_type(remote)
            if remote_type in ["erda", "ucloud"]:
                set_host_port(remote)

        # Dispatch commands
        if args.command == "add":
            oauth_token = getattr(args, "oauth_token", None)
            oauth_token_file = getattr(args, "oauth_token_file", None)

            if oauth_token and oauth_token_file:
                print("Error: use only one of --token or --token-file.")
                sys.exit(2)

            if oauth_token_file:
                token_path = pathlib.Path(oauth_token_file).expanduser().resolve()
                if not token_path.exists():
                    print(f"Error: token file not found: {token_path}")
                    sys.exit(2)
                try:
                    oauth_token = token_path.read_text(encoding="utf-8").strip()
                    # Validate JSON early for clear CLI feedback.
                    json.loads(oauth_token)
                except Exception as e:
                    print(f"Error: invalid token JSON in {token_path}: {e}")
                    sys.exit(2)

            setup_rclone(
                remote,
                local_backup_path=args.local_path,
                oauth_token=oauth_token,
                ssh_mode=getattr(args, "ssh_mode", False),
            )

        elif args.command == "push":
            mode = getattr(args, "mode", "sync")
            push_rclone(
                remote_name=remote,
                new_path=args.remote_path,
                operation=mode,
                dry_run=args.dry_run,
                verbose=args.verbose,
                select_items=getattr(args, "select", False),
            )

        elif args.command == "pull":
            mode = getattr(args, "mode", "sync")
            pull_rclone(
                remote_name=remote,
                new_path=args.local_path,
                operation=mode,
                dry_run=args.dry_run,
                verbose=args.verbose,
                select_items=getattr(args, "select", False),
            )

        elif args.command == "delete":
            delete_remote(remote_name=remote, verbose=args.verbose)

        elif args.command == "diff":
            generate_diff_report(remote_name=remote)

    elif args.command == "transfer":
        # Remote-to-remote transfer
        operation = getattr(args, "mode", "copy")
        dry_run = not args.confirm  # If not confirmed, run in dry-run
        transfer_between_remotes(
            source_remote=args.source.strip().lower(),
            dest_remote=args.destination.strip().lower(),
            operation=operation,
            dry_run=dry_run,
            verbose=args.verbose,
        )

    else:
        # Commands without a remote
        if args.command == "list":
            list_remotes()
        elif args.command == "types":
            list_supported_remote_types()
        else:
            parser.print_help()
            sys.exit(2)


if __name__ == "__main__":
    main()
